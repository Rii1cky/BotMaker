# ModMail Bot

Support me by invite my bot:

https://dsc.gg/bestmusicbot

If you have any question join my server!

https://dsc.gg/r1icky


THIS BOT IS NOT FOR MULTIPLE SERVERS!!